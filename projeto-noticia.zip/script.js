// Executa quando o documento estiver totalmente carregado
document.addEventListener("DOMContentLoaded", () => {
    // Insere a data atual de forma automática no campo correspondente
    const dateElement = document.getElementById("publish-date");
    
    if (dateElement) {
        const today = new Date();
        
        // Formata a data para o padrão brasileiro (DD/MM/AAAA)
        const day = String(today.getDate()).padStart(2, '0');
        const month = String(today.getMonth() + 1).padStart(2, '0'); // Janeiro é 0
        const year = today.getFullYear();
        
        dateElement.textContent = `${day}/${month}/${year}`;
    }
});
